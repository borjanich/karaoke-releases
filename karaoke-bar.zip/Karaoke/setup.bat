@echo off
cd /d "%~dp0"
echo === Karaoke processor setup ===
echo.
where uv >nul 2>nul
if errorlevel 1 if not exist "%USERPROFILE%\.local\bin\uv.exe" (
  echo [1/2] Installing uv ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
)
set "PATH=%USERPROFILE%\.local\bin;%PATH%"
echo.
echo [2/2] Installing Python, PyTorch, Demucs, yt-dlp (about 1.5 GB, takes a while) ...
start "" /wait "%~dp0karaoke.exe" -extract
uv run --script processor\processor.py --selftest
if errorlevel 1 (
  echo.
  echo !!! SETUP FAILED - send the text above to Claude
) else (
  echo.
  echo === DONE. Restart karaoke.exe from the tray. ===
)
pause
